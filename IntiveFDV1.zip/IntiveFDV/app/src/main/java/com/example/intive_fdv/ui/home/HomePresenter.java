package com.example.intive_fdv.ui.home;

import android.content.Context;
import android.util.Log;

import com.example.intive_fdv.api.callers.UsersApiCaller;
import com.example.intive_fdv.api.observer.CallbackHandlingObserver;
import com.example.intive_fdv.api.services.UserRestService;
import com.example.intive_fdv.models.ListUserResponse;
import com.example.intive_fdv.models.User;
import com.google.gson.Gson;

import java.util.List;

public class HomePresenter implements HomeContract.Presenter {

    private Context context;
    private HomeContract.View mView;
    private CallbackHandlingObserver<ListUserResponse> observableUsers;


    public HomePresenter(Context context, HomeContract.View mView) {
        this.context = context;
        this.mView = mView;
    }


    @Override
    public void getUserService(Integer results, Integer page, String seed) {
        setObservableUsers();

        final UsersApiCaller caller = UserRestService.getUserApiCaller(results, page, seed);

        caller.callApi().subscribeWith(observableUsers);

    }

    private void setObservableUsers() {
        observableUsers = new CallbackHandlingObserver<ListUserResponse>(HomePresenter.this, UsersApiCaller.class) {
            @Override
            protected void onSuccess(ListUserResponse data) {
                mView.showUser(data.getUsers());
            }
        };
    }

    @Override
    public void onUnknownError(String error, Class caller) {

    }

    @Override
    public void onTimeoutError(Class caller) {

    }

    @Override
    public void onNetworkError(Class caller) {

    }

    @Override
    public void onBadRequestError(Class caller, String messageError) {

    }

    @Override
    public void onServerError(Class caller) {

    }
}
