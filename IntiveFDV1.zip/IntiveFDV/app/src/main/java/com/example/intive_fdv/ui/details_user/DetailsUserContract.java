package com.example.intive_fdv.ui.details_user;

import com.example.intive_fdv.api.observer.BaseContract;

public interface DetailsUserContract {

    interface View {


    }

    interface Presenter extends BaseContract.ServicePresenter{


    }
}
