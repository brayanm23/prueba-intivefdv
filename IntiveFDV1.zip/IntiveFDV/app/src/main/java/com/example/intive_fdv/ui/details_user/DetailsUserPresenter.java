package com.example.intive_fdv.ui.details_user;

public class DetailsUserPresenter {
}
