package com.example.intive_fdv.ui.details_user;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.intive_fdv.R;
import com.example.intive_fdv.models.User;
import com.example.intive_fdv.utils.CheckRealConnection;
import com.example.intive_fdv.utils.UtilsImage;
import com.google.gson.Gson;

public class DetailsUserActivity extends AppCompatActivity implements DetailsUserContract.Presenter {

    private User user;
    private ImageView imageProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_user);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Bundle extras = getIntent().getExtras();
        user = (User) extras.getSerializable("user");
        initView(user);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initView(User user) {

        new CheckRealConnection(this, new CheckRealConnection.OnCheckConnection() {
            @Override
            public void whileLoad() {

            }

            @Override
            public void onPostConnection(boolean success) {
                if(success){
                    UtilsImage.loadImage(DetailsUserActivity.this, user.getPicture().getLarge(), imageProfile);
                }
            }
        });
    }

    @Override
    public void onUnknownError(String error, Class caller) {

    }

    @Override
    public void onTimeoutError(Class caller) {

    }

    @Override
    public void onNetworkError(Class caller) {

    }

    @Override
    public void onBadRequestError(Class caller, String messageError) {

    }

    @Override
    public void onServerError(Class caller) {

    }
}
