package com.example.intive_fdv.ui.splash;

public class SplashActivity {
}
